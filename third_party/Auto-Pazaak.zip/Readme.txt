Auto-Pazaak mod for KotOR 1 by HDR1

Pazaak in KotOR 1 is a frustrating exercise for a few reasons. However, the biggest problem with Pazaak is the sheer amount you have to play if you want all possible credits from playing cards.

By my calculations - not including infinite Pazaak players - you can earn 17050 credits in the Xbox version and 15950 credits on PC along with some cards and a Vibration Cell, plus a discount in Suvam Tan's shop on Yavin. Sounds good overall - except you have to win a total of 64 matches in Pazaak to get all this. This is ridiculous, especially compared to KotOR 2, where there's only 15 or so matches to win. Even with save-scumming, it's enough to drive a person mad.

This mod is intended for completionist players like myself, who are crazy enough to play 64 matches of Pazaak every time they replay KotOR while hating every second of it.

The mod allows you to simulate playing Pazaak, instead of actually playing Pazaak. However, my intention was not to make a cheat mod but to make a quality of life mod, so this is only for NPCs that have limited rewards. As such, Gelrood on Taris and Toll Apkar on Korriban are not affected, and while Kudos can be played indefinitely, you will not be able to skip his Pazaak matches after you've gotten the Vibration Cell from him - if you want to grind infinite Pazaak matches with him, you have to do it manually. 

List of the NPCs this mod affects and their rewards:

Taris: Niklos - 200 credits
Dantooine: Sol'aa - 600 credits + Pazaak cards
Tatooine: Kudos - 2300 credits + Vibration Cell (see notes)
Tatooine: Furko Nellis - 750 credits
Kashyyyk: Fodo Medo - 1700 credits + Pazaak cards
Manaan: Jolan Aphett - 2000 credits + Pazaak cards
Manaan: Gonto Yas - 2000 credits
Yavin: Suvam Tan - 7500 credits + store discount

Installation: copy the files to your Override folder.

Compatibility: the mod should be compatible with any mod that doesn't alter the included .dlg and .ncs files. I don't think there are many mods that do anything with the Pazaak players, so it should be mostly fine. I think some mods may make alterations to Suvam Tan's dialogue, if you have a mod like that, don't install yav47_suvam.dlg or simpaz_suv.ncs.

Usage:

After installing the mod, when you talk to a Pazaak-playing NPC, you will come across an option to [Simulate Pazaak.] - as long as you have a Pazaak deck. When you choose this option, you will gain all the credits you would normally be able to win from the NPC. Afterwards, you need to talk to the NPC again to get their final Pazaak dialogue and potential extra rewards. For example, after you use Simulate on Sol'aa, you should talk to him again and he will give you the extra cards you get for beating him. Same with every other character who gives you a special reward for beating them enough times. I deliberately made the simulation scripts this way, to avoid potentially breaking dialogue trees and to make sure you couldn't simulate Pazaak multiple times.

Notes:
In the vanilla PC version, Kudos on Tatooine bets only 50 credits in his final two matches, while on Xbox he bets 600. The K1 community patch tried fixing this, but for some reason it sets his wager to 500 instead of 600. All sources I could find mention 600 credits, so I included a fix for this as well, and Kudos now bets 600 credits as he does on Xbox. The total reward you get for simming is thus 2300 credits, and he also bets 600 credits if you decide to play him manually afterwards.

Warnings:
1. It's worth saving before you talk to a Pazaak player, just in case something is broken.

2. ALWAYS talk to the Pazaak players after you beat them. This way you will get their closing dialogue properly which triggers scripts and prevents any potential bugs. I don't know what problems may happen by not talking to them, so just talk to them to be safe.

3. If you play a real game of Pazaak with an opponent, you will NOT be able to sim afterwards. This is to ensure you can't get more credits than intended. Avoid playing for real if you want to simulate.

4. I tried to make sure that you can't lose the option to simulate Pazaak while exploring the dialogue trees, but I may have overlooked something. If you want to be 100% sure, choose the simulate option immediately when it pops up.

5. Be careful with Suvam Tan on Yavin. Due to the way his dialogue is structured, I went with the safe route and made it so you can only sim him when you first ask if he plays Pazaak. If you want to play him, you have to choose that option when it pops up, otherwise, you'll have to play him manually.

Bugs:
1. I could not make Suvam's dialog function properly like the rest. After you beat him, he will not mention giving you a discount, instead, he just says it was a good match. However, if you check his shop, you will see that you do in fact have the discount. He will also no longer play for money. So Suvam works properly, his dialogue is just bugged. I couldn't figure out how to fix it, so I don't intend to fix this anytime soon. However I included the source script for him, in case anyone wants to take a shot at it.

2. Not a bug, but obviously if you simulate Pazaak, you will not get to see the progressing dialogue as you will skip ahead to the end. As such, some unique dialogue will not be available with the Pazaak players. This is mainly just them increasingly praising you or complaining about losing. Some of it is a bit funny, but none of it is relevant.


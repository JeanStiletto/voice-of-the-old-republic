void main() {
  SetGlobalBoolean("G_Paz_JustPlayed", 1);
	SetGlobalNumber("YAV_SUVAM_NUM", 10);
  GiveGoldToCreature(GetPCSpeaker(), 7500);


}

